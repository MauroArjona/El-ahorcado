Este es mi primer proyecto el juego del ahorcado.
