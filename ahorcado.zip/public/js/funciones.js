function id( string ){
    return document.getElementById( string );
}
